public class Calculation extends AbstractMessage {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
}
