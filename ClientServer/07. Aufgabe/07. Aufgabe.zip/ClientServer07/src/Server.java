import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Server {	
	ExecutorService executor = Executors.newCachedThreadPool();
	Socket socket;
	
    public static void main(String[] args) {
    	
        Server server = new Server();
        server.start();
    }
       
    public void start() {  	
          try {
             @SuppressWarnings("resource")
             ServerSocket listener = new ServerSocket(4242);

             System.out.println("Server gestartet");
             while(true) {
                 socket = listener.accept();                                                  //Auf Verbindungen wird gewartet
                 System.out.println("Verbunden mit Client: " + socket.getLocalSocketAddress());
                 executor.execute(new ServerThread(socket, this));
                 }
            }catch (Exception e) {
                System.out.println("Ein Fehler ist aufgetreten");
                e.printStackTrace();
            }
            System.out.println("Server beendet");
        }
    	
    public void Shutdown(){
        try {
            socket.close();
            executor.shutdown();
            executor.shutdownNow();
            System.exit(0);  

        }catch (Exception e) {
            System.out.println("Fehler beim Shutdown des Servers");
        }
    }
}
