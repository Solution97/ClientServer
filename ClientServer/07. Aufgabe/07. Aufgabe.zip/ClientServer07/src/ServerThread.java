import java.io.*;
import java.net.Socket;

public class ServerThread extends Thread {
    private Socket conn;
    private Server s;

    public ServerThread(Socket conn, Server s) throws IOException {
        this.conn = conn;
        this.s = s;
    }

    @Override
    public void run() {
        try {
            ObjectInputStream in = new ObjectInputStream(conn.getInputStream());

            Calculation c = (Calculation) in.readObject();
            ObjectOutputStream out = new ObjectOutputStream(conn.getOutputStream());
            if (c.getMessage().equals("0")) {

                double rn = Math.random()*99*(Math.random())*100;
                Thread.sleep(1000);                               
                System.out.println("Wert:" + rn);
                c.setZahl1(0);

                c.setMessage(String.valueOf(rn));
                out = new ObjectOutputStream(conn.getOutputStream());
                out.writeObject(c);
            } 
            
            if (c.getMessage().equals("shutdown")) {
                System.out.println("Server wird beendet");
                s.Shutdown();
            } 
            
            if (c.getMessage().equals("1")) {
                long dt = System.currentTimeMillis();
                Thread.sleep(1000);                          
                System.out.println("Wert:" + dt);
                c.setMessage(String.valueOf(dt));
                c.setZahl1(1);

                out = new ObjectOutputStream(conn.getOutputStream());
                out.writeObject(c);
            }
        } catch (Exception e) {
            System.out.println("Fehler bei der Verbindung zwischen Client und Server");
            e.printStackTrace();
        }finally {
            try {
                conn.close();
            } catch (Exception e) {
                System.out.println("Fehler Server");
                e.printStackTrace();

            }
        }
    }
}





