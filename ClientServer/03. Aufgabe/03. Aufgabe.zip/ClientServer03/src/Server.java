import java.io.*;

import java.net.MalformedURLException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URL;

public class Server {
        public static void main(String[] args) throws IOException {
            ServerSocket s = new ServerSocket(4242);
            
            try {
                System.out.println("Server gestartet");
                while (true) {
                    Socket socket = s.accept();                                                
                    System.out.println("Verbunden mit Client: " + socket.getLocalSocketAddress());

                    try {
                        ObjectInputStream in = new ObjectInputStream(socket.getInputStream());
                        try {
                            Url a = (Url) in.readObject();
                            //gelesener Path wird geholt
                            String path = a.getMessage();
                            System.out.println(path + " wird heruntergeladen");
                            //Downloader wird erstellt um herunterzuladen	
                            WebDownloader wd = new WebDownloader();

                            try {
                            	//datei wird mit dem namen done.html gespeichert
                                wd.saveTo(new URL(path),"done.html");                

                            } catch (MalformedURLException e) {
                                e.printStackTrace();
                            }

                            OutputStream out = socket.getOutputStream();
                            //angegeben wo hin geschrieben werden soll
                            InputStream Fin = new FileInputStream("done.html");
                            
                            //in die datei schreiben
                            byte[] buffer = new byte[1024];
                            while (Fin.available() > 0) {
                                out.write(buffer, 0, Fin.read(buffer));
                            }

                            Fin.close();

                        } catch (Exception e) {
                            System.out.println("Fehler bei der Verbindung zwischen Client und Server");
                        }
                    } finally {
                        socket.close();           
                    }
                }
            }
            finally {
                s.close();
                System.out.println("Server beendet");
            }
        }
}
