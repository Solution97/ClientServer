import javax.swing.JOptionPane;
import java.io.*;
import java.net.Socket;

public class Client {
//Was nict kommentiert ist, ist gleich wie bei den anderen �bungen
        public static void main(String[] args) throws IOException {
        	//Objekt wird erzeugt
            Url url = new Url(); 
            	
                String serverAddress = "127.0.0.1";
                             
                String enter =  JOptionPane.showInputDialog("Gib die Server Adresse ein! ('quit' um zu beenden)"); 
                
                if (enter.equals("quit")) {
                    System.exit(0);
                }else if(enter!=null){
                    serverAddress=enter;
                }

            while(true) {   
                enter = JOptionPane.showInputDialog("URL eingeben (mit http oder https) oder 'quit' um zu beenden");
                if (enter.equals("quit")) {
                    break;
                } else if (enter != null) {

                	url.setMessage(enter);
                    @SuppressWarnings("resource")
					Socket s = new Socket(serverAddress, 4242);                                        
                    ObjectOutputStream out = new ObjectOutputStream(s.getOutputStream());
                    out.writeObject(url);
                    out.flush();
                }
            }
            System.out.println("Programm beendet");
        }
}
