import java.io.Serializable;

public abstract class AbstractMessage implements Serializable {
//gleich wie immer
	private static final long serialVersionUID = 1L;
	Integer Zahl1;
    String Message;

    public String getMessage() {
        return Message;
    }

    public Integer getZahl1() {
        return Zahl1;
    }
    public void setZahl1(Integer nZahl1) {
    	Zahl1 = nZahl1;
    }

    public void setMessage(String message) {
        Message = message;
    }

}
