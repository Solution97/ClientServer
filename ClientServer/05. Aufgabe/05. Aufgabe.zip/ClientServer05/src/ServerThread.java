import java.io.*;
import java.net.Socket;
import java.nio.file.Path;
import java.nio.file.Paths;

public class ServerThread extends Thread {
    private Socket conn;
    @SuppressWarnings("unused")
	private Server s;
    BufferedReader in = null;
    PrintWriter out;

    public ServerThread(Socket conn, Server s) throws IOException {

        this.conn = conn;
        this.s = s;
        in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        out = new PrintWriter(conn.getOutputStream(), true);
    }

    //run methode des threads
    @Override
    public void run() {
        try {
            ObjectInputStream in = new ObjectInputStream(conn.getInputStream());
            try {
            	//Daten werden geholt
            	FilePath a = (FilePath) in.readObject();                                          //Datei wird geöffnet und gesendet
                Path Link = (Paths.get(a.getMessage()));

                OutputStream out = conn.getOutputStream();
                InputStream fIn = new FileInputStream(Link.toFile());
                
                //schreiben
                byte[] buffer = new byte[1024];
                while (fIn.available() > 0) {
                    out.write(buffer, 0, fIn.read(buffer));
                }
                fIn.close();
            } catch (Exception e) {
                System.out.println("Fehler bei der Verbindung zwischen Server und Client");
                e.printStackTrace();
            }
        	}catch (Exception e) {
                System.out.println("Fehler Server");
        	}finally {
        		try{
        			conn.close();
        			} catch (Exception e) {
	                System.out.println("Ein Fehler ist aufgetreten.");
	                e.printStackTrace();
            }
        }
    }
}





