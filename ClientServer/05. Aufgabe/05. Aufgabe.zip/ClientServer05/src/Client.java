import java.io.*;
import java.net.Socket;

import java.nio.file.Paths;

import javax.swing.JOptionPane;

public class Client {

        public static void main(String[] args) throws IOException {
        	FilePath path = new FilePath();                                  
                   
            String serverAddress = "127.0.0.1";
            
            String enter= JOptionPane.showInputDialog("Gib die Server Adresse ein! ('quit' um zu beenden)"); 
                if (enter.equals("quit")) {
                    System.out.println("Programm beendet");
                    System.exit(0);
                }else if(enter != null){
                serverAddress = enter;
                }
                
            while(true) {
                enter = JOptionPane.showInputDialog("Pfad der datei angeben"); 
                if (enter.equals("quit")) {
                    break;
                } else if (enter != null) {

                	path.setMessage(enter);
                    @SuppressWarnings("resource")
					Socket s = new Socket(serverAddress, 4242);                                         //Verbindung wird aufgebaut und Pfad gesendet

                    ObjectOutputStream out = new ObjectOutputStream(s.getOutputStream());
                    out.writeObject(path);
                    out.flush();
                    
                    //datei vom server bekommen
                    String file = Paths.get(path.getMessage()).toString();

                    String extension = "";
                    //dateiendung ermitteln
                    int i = file.lastIndexOf('.');
                    if (i > 0) {
                        extension = file.substring(i+1);
                    }
                    //datei mit name done und entsprechennder endung speichern
                    InputStream in = s.getInputStream();
                    FileOutputStream fileOut = new FileOutputStream("done."+extension);
                    
                    //schreiben
                    byte[] buffer = new byte[1024];                                 //File wird gespeichert
                    while (s.isConnected()) {
                        int bytesRead = in.read(buffer);
                        if (bytesRead == -1) break;
                        fileOut.write(buffer, 0, bytesRead);
                    }
                    fileOut.close();
                }
            }
            System.out.println("Programm beendet");
        }
}
