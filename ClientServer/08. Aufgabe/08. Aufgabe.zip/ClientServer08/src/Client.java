import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;


public class Client {

    BufferedReader in;
    PrintWriter out;
    JFrame frame = new JFrame("Client Server Chat Programm");
    JTextField textField = new JTextField(40);
    JTextArea messageArea = new JTextArea(8, 40);

    public Client() {
    	//desgin der Chatbox
        textField.setEditable(false);
        messageArea.setEditable(false);
        frame.getContentPane().add(textField, "North");
        frame.getContentPane().add(new JScrollPane(messageArea), "Center");
        frame.pack();

        //text vom textfeld wird geholt
        textField.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                out.println(textField.getText());
                textField.setText("");
            }
        });
    }
    
    //verbindung zum server
    private String getServerAddress() {
        return JOptionPane.showInputDialog(
            frame,
            "Gib die Server Adresse ein:",
            "Willkommen",
            JOptionPane.QUESTION_MESSAGE);
    }
    
    //name einlesen
    private String getName() {
        return JOptionPane.showInputDialog(frame,
            "W�hlen sie einen Benutzernamen:",
            "Name w�hlen",
            JOptionPane.PLAIN_MESSAGE);
    }
    
    //thread
    private void run() throws IOException {
        String serverAddress = getServerAddress();
        @SuppressWarnings("resource")
		Socket socket = new Socket(serverAddress, 9001);
        in = new BufferedReader(new InputStreamReader(
            socket.getInputStream()));
        out = new PrintWriter(socket.getOutputStream(), true);

        while (true) {
            String line = in.readLine();
            //name speichern
            if (line.startsWith("NAMEBESTAETIGEN")) {
                out.println(getName());
            } else if (line.startsWith("NAMEANGENOMMEN")) {
            	//falls g�ltiger name textfeld freigeben
                textField.setEditable(true);
            } else if (line.startsWith("NACHRICHT")) {
            	//nachricht in die message area hinzuf�gen
                messageArea.append(line.substring(8) + "\n");
            }
        }
    }

    public static void main(String[] args) throws Exception {
    	//object erstellen
        Client client = new Client();
        //kleine nebeneinstellungen
        client.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        client.frame.setVisible(true);
        //ausf�hren
        client.run();
    }
}