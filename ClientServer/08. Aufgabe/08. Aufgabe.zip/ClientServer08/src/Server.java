import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashSet;

public class Server {
   
    private static HashSet<String> namen = new HashSet<String>();
    
    private static HashSet<PrintWriter> nachrichten = new HashSet<PrintWriter>();

    public static void main(String[] args) throws Exception {
        System.out.println("Server gestartet");
        ServerSocket listener = new ServerSocket(4242);
        try {
            while (true) {
                new Handler(listener.accept()).start();
            }
        } finally {
            listener.close();
        }
    }

    private static class Handler extends Thread {
        private String name;
        private Socket socket;
        private BufferedReader in;
        private PrintWriter out;

        public Handler(Socket socket) {
            this.socket = socket;
        }
        
        //Thread wird gestartet
        public void run() {
            try {
                in = new BufferedReader(new InputStreamReader(
                    socket.getInputStream()));
                out = new PrintWriter(socket.getOutputStream(), true);

                while (true) {
                    out.println("NAMEBESTAETIGEN");
                    //name wird festgelegt
                    name = in.readLine();
                    if (name == null) {
                        return;
                    }
                    //falls name nicht exisitert adden
                    synchronized (namen) {
                        if (!namen.contains(name)) {
                        	namen.add(name);
                            break;
                        }
                    }
                }
                out.println("NAMEANGENOMMEN");
                nachrichten.add(out);
                //nachricht wird geadded
                
                while (true) {
                	//eingabe wird gelese
                    String input = in.readLine();
                    //falls leer abbruich
                    if (input == null) {
                        return;
                    }
                    //jede nachricht in nachrichten wird gepostet
                    for (PrintWriter nachricht : nachrichten) {
                    	nachricht.println("NACHRICHT " + name + ": " + input);
                    }
                }
            } catch (IOException e) {
                System.out.println(e);
            } finally {
                if (name != null) {
                	namen.remove(name);
                }
                if (out != null) {
                	nachrichten.remove(out);
                }
                try {
                    socket.close();
                } catch (IOException e) {
                }
            }
        }
    }
}