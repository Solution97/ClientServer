import java.io.*;
import java.net.Socket;

import javax.swing.JOptionPane;

public class Client { 

        public static void main(String[] args) throws IOException {
            Message m = new Message();  
            //Authentifizierung
            String auth= JOptionPane.showInputDialog("Geben Sie Ihren Namen ein"); 
            //�berpr�fen ob nicht leer und begr��en
            if (auth.equals("")) {
            	System.out.println("Nicht leer lassen!");
            	System.exit(0);
            }else if(auth!=null){
                System.out.println("Willkommen " + auth);
            }
            //rest wie bei 01
            while(true){ 				

                String serverAddress = "127.0.0.1";

                String enter= JOptionPane.showInputDialog("Gib die Server Adresse ein! ('quit' um zu beenden)");
                
                
                if (enter.equals("quit")) {
                    break;
                }else if(enter!=null){
                    serverAddress=enter;
                }

                int Zahl1 = 0;
                int Zahl2 = 0;
                String op = "";

                try {
                    Zahl1 = Integer.parseInt(JOptionPane.showInputDialog("Erste Zahl der Berechnung (Ganze Zahl):"));

                    op = JOptionPane.showInputDialog("Operator (+ | - | * | /");

                    Zahl2 = Integer.parseInt(JOptionPane.showInputDialog("Zweite Zahl der Berechnung (Ganze Zahl):"));

                }catch(java.lang.NumberFormatException e){                                  //Falls falsch eingegeben wird neu begonnen
                    System.out.println("Falsche Eingabe. Bitte erneut versuchen!");


                }catch(java.lang.NullPointerException e){                                  //Falls falsch eingegeben wird neu begonnen
                    System.out.println("Falsche Eingabe. Bitte erneut versuchen!");

                }
                
                m.setZahl1(Zahl1);
                m.setZahl2(Zahl2);
                m.setMessage(op);

                Socket s = new Socket(serverAddress, 4242);                                         //Verbindung wird aufgebaut

                ObjectOutputStream out = new ObjectOutputStream(s.getOutputStream());

                out.writeObject(m);                                                                 //Objekt wird gesendet

                InputStreamReader in = new InputStreamReader(s.getInputStream());

                int answer = in.read();                                                      //Ergebniss wird empfangen und ausgegeben

                JOptionPane.showMessageDialog(null, "Das Ergebnis lautet: " + answer);

                s.close();
            }
            System.out.println("Berechnung Beendet");
        }
}
