import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
public class Server {

		//Alles gleich wie bei 01
        public static void main(String[] args) throws IOException {
            ServerSocket listener = new ServerSocket(4242);
            try {
                System.out.println("Server wurede gestartet");
                while (true) {
                    Socket socket = listener.accept();                                                  //Auf Verbindungen wird gewartet
                    System.out.println("Verbunden mit Client: " +socket.getLocalSocketAddress());

                    try {

                    	ObjectInputStream in = new ObjectInputStream(socket.getInputStream());
                        try{
                        Message m = (Message)in.readObject();                                           //Erhaltennes Objekt wird in Message umgewandet
                            OutputStreamWriter out = new OutputStreamWriter(socket.getOutputStream());

                            if(m.getMessage().equals("+")) out.write(m.getZahl1()+m.getZahl2());                                         
                            
                            if(m.getMessage().equals("-")) out.write((m.getZahl1()-m.getZahl2()));
                         
                            if(m.getMessage().equals("*")) out.write((m.getZahl1()*m.getZahl2()));

                            if(m.getMessage().equals("/")) out.write((m.getZahl1()/m.getZahl2()));
         
                            out.flush();

                        }catch (java.lang.ClassNotFoundException e){

                            System.out.println("Fehler bei der Kommunikation zwischen Client und Server");
                        }
                    } finally {
                        socket.close();
                        System.out.println("Ihre Rechnung wurde erfolgreich berechnet");
                    }
                }

            }
            finally {
                listener.close();
                System.out.println("Server beendet");
            }
        }





}
