import java.io.Serializable;

public abstract class AbstractMessage implements Serializable {

	private static final long serialVersionUID = 1L;
	Integer Zahl1;
	Integer Zahl2;
    String Message;

    public String getMessage() {
        return Message;
    }
    
    public void setMessage(String message) {
        Message = message;
    }

    public Integer getZahl1() {
        return Zahl1;
    }
    public void setZahl1(Integer nZahl1) {
    	Zahl1 = nZahl1;
    }
    
    public void setZahl2(Integer nZahl2) {
    	Zahl2 = nZahl2;
    }
    public Integer getZahl2() {
            return Zahl2;
    }
}
