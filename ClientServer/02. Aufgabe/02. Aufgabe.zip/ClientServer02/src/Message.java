public class Message extends AbstractMessage  { 

	private static final long serialVersionUID = 1L;

	//Gleich wie bei 01
}