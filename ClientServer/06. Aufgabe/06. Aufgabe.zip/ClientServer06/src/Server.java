import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
//import java.text.DecimalFormat;

public class Server {

    public static void main(String[] args) {
        Server server = new Server();
        //Server starten
        server.start();
    }
    
    public void start() {
        while (true) {
            try {
                @SuppressWarnings("resource")
				ServerSocket listener = new ServerSocket(4242);

                System.out.println("Server gestartet");
                while (true) {
                    Socket socket = listener.accept();                                                  //Auf Verbindungen wird gewartet
                    System.out.println("Verbunden mit Client: " + socket.getLocalSocketAddress());
                    try {
                        ObjectInputStream in = new ObjectInputStream(socket.getInputStream());

                        Calculation c = (Calculation) in.readObject();
                        //Option aususchen
                        //bei 0
                        if (c.getMessage().equals("0")) {
                            double rn = Math.random()*99*(Math.random())*100;
                            //DecimalFormat df = new DecimalFormat("#.##");                    
                            Thread.sleep(1000);
                            c.setZahl1(0);
                            c.setMessage(String.valueOf(rn));
                        } else { //bei 1
                            long dt = System.currentTimeMillis();
                            Thread.sleep(1000);
                            c.setMessage(String.valueOf(dt));
                            c.setZahl1(1);
                        }
                        ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
                        out.writeObject(c);

                    } catch (Exception e) {

                        System.out.println("Fehler bei der Verbindung zwischen Client und Server");
                        e.printStackTrace();
                    }
                }
            } catch (Exception e) {
                System.out.println("Es ist ein Fehler aufgetreten");
                e.printStackTrace();
                break;
            }
        }
        System.out.println("Server beendet");
    }
}
