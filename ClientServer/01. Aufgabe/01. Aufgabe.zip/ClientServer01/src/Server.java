import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
public class Server {

        public static void main(String[] args) throws IOException {
        	//Server wird gestartet
            ServerSocket listener = new ServerSocket(4242);
            try {
                System.out.println("Server wurede gestartet");
                while (true) {
                	//Server wartet nun auf Aufgaben
                    Socket socket = listener.accept();   
                    //Client Verbindet sich und seine Adresse wird ausgegeben
                    System.out.println("Verbunden mit Client: " +socket.getLocalSocketAddress());

                    try {
                    	//InputStream zum Empfangen der Objekte wird erstellt
                    	ObjectInputStream in = new ObjectInputStream(socket.getInputStream());
                        try{
                        //Die gespeicherten Werte werden eingelesen
                        Message m = (Message)in.readObject(); 
                        	//OutputStream zum Senden des Ergebnises wird erstellt
                            OutputStreamWriter out = new OutputStreamWriter(socket.getOutputStream());
                            //Rechnung wird berechnet und �ber OutpuSteam versendet.
                            if(m.getMessage().equals("+")) out.write(m.getZahl1()+m.getZahl2());                                         
                            
                            if(m.getMessage().equals("-")) out.write((m.getZahl1()-m.getZahl2()));
                         
                            if(m.getMessage().equals("*")) out.write((m.getZahl1()*m.getZahl2()));

                            if(m.getMessage().equals("/")) out.write((m.getZahl1()/m.getZahl2()));
                            //Flush um sicher zu gehen dass gesendet wird
                            out.flush();
                          //Einige Exceptions abfangen
                        }catch (java.lang.ClassNotFoundException e){
                            System.out.println("Fehler bei der Kommunikation zwischen Client und Server");
                        }
                    } finally {
                        socket.close();
                        //Server Socket schlie�en
                        System.out.println("Ihre Rechnung wurde erfolgreich berechnet");
                    }
                }
            }
            finally {
            	//Server beenden
                listener.close();
                System.out.println("Server beendet");
            }
        }
}
