public class Message extends AbstractMessage  {

	private static final long serialVersionUID = 1L;
	//Um ein Object von AbstractMessage erstellen zu k�nnen brauch es diese Klasse

}