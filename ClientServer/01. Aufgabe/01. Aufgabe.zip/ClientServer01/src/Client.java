import java.io.*;
import java.net.Socket;

import javax.swing.JOptionPane;

public class Client {
        public static void main(String[] args) throws IOException {
        	//Objekt wird erstellt
            Message m = new Message();  

            while(true){		

                String serverAddress = "127.0.0.1"; //Stardard Wert

                //IP-Adresse Eingabefeld
                String enter= JOptionPane.showInputDialog("Gib die Server Adresse ein! ('quit' um zu beenden)"); 
                
                //Falls Eingabe ist 'quit' soll das Prg. beendet werden
                if (enter.equals("quit")) {
                    break;
                }else if(enter!=null){
                    serverAddress=enter; //sonst ist die IP-Adresse die eingegebene IP
                }

                int Zahl1 = 0;
                int Zahl2 = 0;  //Notwendige Variablen deklarienen
                String op = "";

                try {
                	//Erste eingegebnene Zahl abspeichern
                    Zahl1 = Integer.parseInt(JOptionPane.showInputDialog("Erste Zahl der Berechnung (Ganze Zahl):"));
                    //Operator abspeichern
                    op = JOptionPane.showInputDialog("Operator (+ | - | * | /");
                    //Zweite eingegebnene Zahl abspeichern
                    Zahl2 = Integer.parseInt(JOptionPane.showInputDialog("Zweite Zahl der Berechnung (Ganze Zahl):"));
                  //Einige Exceptions abfangen
                }catch(java.lang.NumberFormatException e){                               
                    System.out.println("Falsche Eingabe. Bitte erneut versuchen!");

                }catch(java.lang.NullPointerException e){                                  
                    System.out.println("Falsche Eingabe. Bitte erneut versuchen!");

                }
                //Die Setter in der Abstarcten Klasse mit den gespeicherten Werten setzen
                m.setZahl1(Zahl1);
                m.setZahl2(Zahl2);
                m.setMessage(op);
                
                //Verbing zum Server aufbauen
                Socket s = new Socket(serverAddress, 4242);                                         
                //Outputstream zum Senden des Objektes erstrellen
                ObjectOutputStream out = new ObjectOutputStream(s.getOutputStream());
                //Objekt �ber den Outputstream versenden
                out.writeObject(m);                                                                
                //Inputstream zum Empfangen des Objektes erstrellen
                InputStreamReader in = new InputStreamReader(s.getInputStream());
                //Empfangenes Ergenis wird in die Variable answer gespeichert
                int answer = in.read();                                                      
                //Das Ergebnis wird ausgegeben
                JOptionPane.showMessageDialog(null, "Das Ergebnis lautet: " + answer);
                //Verbindung trennen
                s.close();
            }
           System.out.println("Berechnung Beendet");
        }
}
