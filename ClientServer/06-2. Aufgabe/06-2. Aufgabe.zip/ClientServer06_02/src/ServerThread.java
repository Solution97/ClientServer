import java.io.*;
import java.net.Socket;

public class ServerThread extends Thread {
    private Socket conn;
	@SuppressWarnings("unused")
	private Server s;

    public ServerThread(Socket conn, Server s) throws IOException{
        this.conn = conn;
        this.s = s;
    }
    //Wieder nur eine normale Server Run Methode zum Starten von Threads
    @Override
    public void run() {
        try {
            ObjectInputStream in = new ObjectInputStream(conn.getInputStream());

            Calculation c = (Calculation) in.readObject();
            if (c.getMessage().equals("0")) {
                double rn = Math.random()*99*(Math.random())*100;
                Thread.sleep(1000);
                c.setZahl1(0);
                c.setMessage(String.valueOf(rn));
            } else {
                long dt = System.currentTimeMillis();
                Thread.sleep(1000);
                c.setMessage(String.valueOf(dt));
                c.setZahl1(1);
            }
            ObjectOutputStream out = new ObjectOutputStream(conn.getOutputStream());
            out.writeObject(c);
        }catch (Exception e) {
            System.out.println("Fehler bei der Verbindung zwischen Server und Client");
            e.printStackTrace();
        }finally {
            try {
            	conn.close();
            } catch (Exception e) {
                System.out.println("Es ist ein Fehler aufgetreten");
                e.printStackTrace();
            }
        }
    }
}





