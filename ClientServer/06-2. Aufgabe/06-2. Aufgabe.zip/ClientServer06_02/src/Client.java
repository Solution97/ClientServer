import java.io.*;
import java.net.Socket;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.swing.JOptionPane;

public class Client {

//wie vorher
    public static void main(String[] args) throws IOException {

        Calculation c = new Calculation();

        String serverAddress = "127.0.0.1";
        
        String enter= JOptionPane.showInputDialog("Gib die Server Adresse ein! ('quit' um zu beenden)");
        if (enter.equals("quit")) {
            System.out.println("Programm beendet");
            System.exit(0);
        } else if (enter != null) {
            serverAddress = enter;
        }
        while(true) {
        	enter = JOptionPane.showInputDialog("W�hle: Random(0) || Date(1) oder 'quit' um zu beenden");
            if (enter.equals("quit")) {
                break;
            } else if (enter != null) {
                try {
                    c.setMessage(enter);
                    @SuppressWarnings("resource")
					Socket s = new Socket(serverAddress, 4242);                                         //Verbindung wird aufgebaut und Pfad gesendet
                    Calculation c1 = new Calculation();
                    c1.setMessage(enter);

                    ObjectOutputStream out = new ObjectOutputStream(s.getOutputStream());
                    out.writeObject(c1);

                    ObjectInputStream in = new ObjectInputStream(s.getInputStream());
                    c1 = (Calculation) in.readObject();

                    if(c1.getZahl1()==1){
                        DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy/hh:mm:ss");
                        Calendar cal = Calendar.getInstance();
                        cal.setTimeInMillis(Long.parseLong(c1.getMessage()));
                        System.out.println("Das heutige Datum lautet: " + formatter.format(cal.getTime()));
                    }else{
                        System.out.println("Der Zufallswert lautet: " + c1.getMessage());
                    }
                } catch (Exception e) {
                    System.out.println("Fehler bei der Verbindung zwischen Client und Server");
                    e.printStackTrace();
                }
            }
        }
        System.out.println("Programm beendet");
    }
}
